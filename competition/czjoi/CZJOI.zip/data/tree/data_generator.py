from cyaron import *
import random

_n = ati([0, 10, 100, 100, 1E4, 1E4, 1E4, 1E5, 1E5, 1E5, 1E5])

for i in range(0, 11):
    test_data = IO(file_prefix="tree", data_id=i)

    n = _n[i]
    test_data.input_writeln(n)

    lch = "LCH"
    st = ""
    for j in range(n):
        st += lch[random.randint(0, 2)]

    test_data.input_writeln(st)

    tree = Graph.tree(n)
    # test_data.input_writeln(tree)

    for edge in tree.iterate_edges():
        test_data.input_writeln(edge.start, edge.end)

    test_data.output_gen("./tree")
