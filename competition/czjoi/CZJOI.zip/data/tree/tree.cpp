#include <bits/stdc++.h>
using namespace std;
#define MxN 100010
#define p 1000000007

int n, a[MxN], hd[MxN], res = 0, tot = 0, L[MxN], H[MxN], sL = 0, sH = 0, f[MxN];
struct node {
    int y, to;
    node(int y = 0, int to = 0) : y(y), to(to) {}
}e[MxN * 2];

void add(int x, int y) {
    e[++ tot] = node(y, hd[x]), hd[x] = tot;
}

void dfs(int x, int fa) {
    f[x] = fa;
    if (a[x] == 1) L[x] = 1;
    else if (a[x]) H[x] = 1;
    for (int i = hd[x]; i; i = e[i].to) {
        int y = e[i].y;
        if (y == fa) continue;
        dfs(y, x);
        L[x] += L[y], H[x] += H[y];
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin >> n;
    for (int i = 1; i <= n; i ++) {
        char c; cin >> c;
        if (c == 'C') a[i] = 0;
        if (c == 'L') a[i] = 1, sL ++;
        if (c == 'H') a[i] = 2, sH ++;
    } 
    for (int i = 1, x, y; i < n; i ++) {
        cin >> x >> y, add(x, y), add(y, x);
    }
    dfs(1, 0);
    for (int i = 1; i <= n; i ++) {
        if (a[i]) continue;
        int tN = 0, tI = 0;
        for (int j = hd[i]; j; j = e[j].to) {
            int y = e[j].y;
            if (y == f[i]) continue;
            (res += L[y] * tI) %= p, tI += H[y];
            (res += H[y] * tN) %= p, tN += L[y];
        }
        (res += (sL - tN) * tI) %= p;
        (res += (sH - tI) * tN) %= p;
    }
    cout << res << endl;
    return 0;
}
