from cyaron import *
import os

for i in range(1, 21):
    os.system("./navigation > " + str(i) + ".out" + "<" + str(i) +".in")
