#include <bits/stdc++.h>

#define N 220006
#define ll long long

using namespace std;

long double sum[N];

int n;
int L,R;
int mx;

int num[N];

int l[2],r[2];
int Q[2][N];

ll ans;

int read()
{
    int x = 0, f = 1;
    char ch = getchar();
    while (ch < '0' || ch > '9')
    {
        if (ch == '-')
            f = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9')
    {
        x = x * 10 + ch - '0';
        ch = getchar();
    }
    return x * f;
}

ll gcd(ll x,ll y)
{
    return x == 0 ? y : gcd(y % x, x);
}

bool check(long double y)
{
    for (int i = 1; i <= n; i++)
        sum[i] = sum[i - 1] + num[i] - y;
    l[0] = 1; l[1] = 1;
    r[0] = 0; r[1] = 0;
    for (int i = L; i<= n; i++)
    {
        int w = i & 1, x = i - L;
        while (r[w] >= l[w] && sum[x] < sum[Q[w][r[w]]])
            r[w]--;
        while (r[w] >= l[w] && Q[w][l[w]] < i - R)
            l[w]++;
        Q[w][++r[w]] = x;
        if (sum[i] - sum[Q[w][l[w]]] >= 0)
            return ans = i - Q[w][l[w]];
    }
    return 0;
}

int main()
{
    n = read(); L = read(); R = read();
    for (int i = 1; i <= n; i++)
        num[i] = read(), mx = max(mx,num[i]);
    for (int i = 1; i <= n; i++)
        num[n + i] = num[i];
    if (L & 1)
        L++;
    if (R & 1)
        R--;
    n *= 2;
    long double l = 0, r = mx;
    while (r - l > 1e-7)
    {
        long double mid = (l + r) / 2;
        if (check(mid))
            l = mid;
        else r = mid;
    }
    long double tmp = (l + r) / 2;
    ll w = (ll)(ans * tmp + 0.5);
    ll Gcd = gcd(w,ans);
    w /= Gcd; ans /= Gcd;
    if (ans == 1)
        cout<<w<<endl;
    else cout<<w<<'/'<<ans<<endl;
}