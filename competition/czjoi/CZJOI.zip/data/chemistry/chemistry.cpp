#include <algorithm>
#include <iostream>
#include <cctype>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <vector>
#include <queue>
using namespace std;

inline int ReadInt() {
    static int n, ch;
    n = 0, ch = getchar();
    while (!isdigit(ch)) ch = getchar();
    while (isdigit(ch)) n = (n << 3) + (n << 1) + ch - '0', ch = getchar();
    return n;
}

const int maxn = 100000 + 3, maxh = 500 + 3;
int mx[maxn], f[maxn][maxh], ans[maxn], n;
vector<int> G[maxn];

void dfs(int u) {
    f[u][0] = 1;
    for (int i = 0; i < G[u].size(); ++i) {
        int v = G[u][i];
        dfs(v);
        for (int j = 0; j <= mx[u]; ++j)
            for (int k = 0; k <= mx[v]; ++k)
                ans[j ^ (k + 1)] += f[u][j] * f[v][k]; //统计答案
        mx[u] = max(mx[u], mx[v] + 1);
        for (int j = 0; j <= mx[v]; ++j)
            f[u][j + 1] += f[v][j]; //从子树的信息更新自己
    }
}

int main() {
    n = ReadInt();
    for (int i = 1; i < n; ++i) {
        int f = ReadInt() - 1; 
        G[f].push_back(i);
    }
    dfs(0);
    for (int i = 0; i < n; ++i) {
        if (ans[i] == 0) break;
        printf("%d\n", ans[i]);
    }
    return 0;
}
